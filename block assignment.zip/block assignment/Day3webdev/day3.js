//conditionals- leads to a boolean = is it true or false IF statement is creating conditional block

if(i !== 100){
    console.log("I is not 100")

}
else{
    console.log("I is greater than100")
}
//the answer is not always yes and no or true and false 

//what is your age group? depending on your age- you can and can't do certian  things
//under 18
//over 18 and under 21 
//over 21

//else if stateents if the first condition is false. in a conditional block you can only have one else if statemwnt 

var age = 41
if (age >= 21){
    console.log("you can purchace alcohol, tobacco, and others")
}
else if (age >=18 && age <= 21){
    console.log("buy lottery tix")
}
else{
    console.log("you can get a slurpee")
}
// or operator- as long as one of the stsatemnts is true all of it is true 

if(firstName.length > 0){

}
if(lastName.length > 0){

}
if(password.length > 8){

}
if(password === confirmPassword){

}

//

