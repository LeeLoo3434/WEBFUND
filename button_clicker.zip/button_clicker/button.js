// function for logout button
function clicked(element){
    console.log("logout")
    element.innerText= "logout"
}
// function for add definition 
function goaway(element){
    console.log(" ")
    element.remove()
}


// function for make add definition go away






